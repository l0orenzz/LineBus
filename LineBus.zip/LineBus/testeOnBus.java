package LineBus;
import java.util.Scanner;
public class testeOnBus {
	
	public static void main (String[] args) {
	
	int destino;
	int origem;
	
	//linhas fixas
	
	int para1 [] = {1,2,8,9};
	int para2 [] = {4,5,6,3,7};
	int para3 [] = {7,3,2,9};
	int para4 [] = {1,6,7};
	int para5 [] = {1,4,5,6,3};
	int para6 [] = {2,4,5,6,3};
	int para7 [] = {3,2};
	int para8 [] = {9,8,2,1,4,5,6,3,7}; //pinga geral, preco mais barato
	
	
	
	
	
	//setando a linha desejada
	linha linhaX = new linha("local","local");
	
	Scanner scanner = new Scanner(System.in);
	System.out.println("1 = São Leopoldo\n2 = Novo Hamburgo"
			+ "\n3 = Porto Alegre\n4 = Sapucaia\n5 = Esteio\n6 = Canoas"
			+ "\n7 = Gravataí\n8 = Campo Bom\n9 = Taquara");
	System.out.println("Escolha sua origem: ");
	origem = scanner.nextInt();
	System.out.println("1 = São Leopoldo\n2 = Novo Hamburgo"
			+ "\n3 = Porto Alegre\n4 = Sapucaia\n5 = Esteio\n6 = Canoas"
			+ "\n7 = Gravataí\n8 = Campo Bom\n9 = Taquara");
	System.out.println("Escolha seu destino: ");
	destino = scanner.nextInt();
	
	
	switch (origem) {
	case 1 : linhaX.setOrigem("São Leopoldo"); break;
	case 2 : linhaX.setOrigem("Novo Hamburgo"); break;
	case 3 : linhaX.setOrigem("Porto Alegre"); break;
	case 4 : linhaX.setOrigem("Sapucaia"); break;
	case 5 : linhaX.setOrigem("Esteio"); break;
	case 6 : linhaX.setOrigem("Canoas"); break;
	case 7 : linhaX.setOrigem("Gravataí"); break;
	case 8 : linhaX.setOrigem("Campo Bom"); break;
	case 9 : linhaX.setOrigem("Taquara"); break;
	}
	switch (destino) {
	case 1 : linhaX.setDestino("São Leopoldo"); break;
	case 2 : linhaX.setDestino("Novo Hamburgo"); break;
	case 3 : linhaX.setDestino("Porto Alegre"); break;
	case 4 : linhaX.setDestino("Sapucaia"); break;
	case 5 : linhaX.setDestino("Esteio"); break;
	case 6 : linhaX.setDestino("Canoas"); break;
	case 7 : linhaX.setDestino("Gravataí"); break;
	case 8 : linhaX.setDestino("Campo Bom"); break;
	case 9 : linhaX.setDestino("Taquara"); break;
	}
	
	//print do local de saida e chegada
	System.out.println(linhaX.toString());
  
	
	
	
	
	
	
	
	
	int x1=0;  //VARIAVEL PARA A LINHA1
	
	for(int i = 0; i<para1.length; i++) {
		
		if ((para1[i]==origem)||(para1[i]==destino)) {
			x1+=1;
		}}
		
		if (x1==2) {System.out.println("linha1 é uma opcao");
		linhass linha1 = new linhass("linha 1",10001, "o",18);
		if (origem==1) {linha1.setHorario("09:30");System.out.println(linha1.toString());}
		else if(origem==2) {linha1.setHorario("09:50"); System.out.println(linha1.toString());}
		else if(origem==8) {linha1.setHorario("10:20"); System.out.println(linha1.toString());}
		else if(origem==9) {linha1.setHorario("10:50"); System.out.println(linha1.toString());} 
		}  
		
	
	int x2=0;  //VARIAVEL PARA A LINHA2
		
	for(int i = 0; i<para2.length; i++) {
			
		if ((para2[i]==origem)||(para2[i]==destino)) {
			x2+=1;
		}}
			
		if (x2==2) {System.out.println("linha2 é uma opcao");
		linhass linha2 = new linhass("linha 2",10011, "o", 16);
		if (origem==4) {linha2.setHorario("14:10");System.out.println(linha2.toString());}
		else if(origem==5) {linha2.setHorario("14:20"); System.out.println(linha2.toString());}
		else if(origem==6) {linha2.setHorario("14:30"); System.out.println(linha2.toString());}
		else if(origem==3) {linha2.setHorario("14:40"); System.out.println(linha2.toString());} 
		else if(origem==7) {linha2.setHorario("15:00"); System.out.println(linha2.toString());} 
		}	
	
	int x3=0;	
		
	for(int i = 0; i<para3.length; i++) {
			
		if ((para3[i]==origem)||(para3[i]==destino)) {
			x3+=1;
		}}
				
		if (x3==2) {System.out.println("linha3 é uma opcao");
		linhass linha3 = new linhass("linha 3",10111, "o",18);
		if (origem==7) {linha3.setHorario("12:00");System.out.println(linha3.toString());}
		else if(origem==3) {linha3.setHorario("12:20"); System.out.println(linha3.toString());}
		else if(origem==2) {linha3.setHorario("13:10"); System.out.println(linha3.toString());}
		else if(origem==9) {linha3.setHorario("13:30"); System.out.println(linha3.toString());} 
		}	
	
	int x4=0;	
		
	for(int i = 0; i<para4.length; i++) {
			
		if ((para4[i]==origem)||(para4[i]==destino)) {
			x4+=1;
		}}
				
		if (x4==2) {System.out.println("linha4 é uma opcao");
		linhass linha4 = new linhass("linha 4",11111, "o",20);
		if (origem==1) {linha4.setHorario("16:30");System.out.println(linha4.toString());}
		else if(origem==6) {linha4.setHorario("16:55"); System.out.println(linha4.toString());}
		else if(origem==7) {linha4.setHorario("17:10"); System.out.println(linha4.toString());}
		}	

	int x5=0;	
		
	for(int i = 0; i<para5.length; i++) {
				
		if ((para5[i]==origem)||(para5[i]==destino)) {
			x5+=1;
		}}
					
		if (x5==2) {System.out.println("linha5 é uma opcao");
		linhass linha5 = new linhass("linha 5",11110, "o", 16);
		if (origem==1) {linha5.setHorario("08:00");System.out.println(linha5.toString());}
		else if(origem==4) {linha5.setHorario("08:10"); System.out.println(linha5.toString());}
		else if(origem==5) {linha5.setHorario("08:20"); System.out.println(linha5.toString());}
		else if(origem==6) {linha5.setHorario("08:30"); System.out.println(linha5.toString());} 
		else if(origem==3) {linha5.setHorario("08:40"); System.out.println(linha5.toString());} 
		}

	int x6=0;	
		
	for(int i = 0; i<para6.length; i++) {
				
		if ((para6[i]==origem)||(para6[i]==destino)) {
			x6+=1;
		}}
					
		if (x6==2) {System.out.println("linha6 é uma opcao");
		linhass linha6 = new linhass("linha 6",11101, "o", 16);
		if (origem==2) {linha6.setHorario("18:30");System.out.println(linha6.toString());}
		else if(origem==4) {linha6.setHorario("19:00"); System.out.println(linha6.toString());}
		else if(origem==5) {linha6.setHorario("19:10"); System.out.println(linha6.toString());}
		else if(origem==6) {linha6.setHorario("19:20"); System.out.println(linha6.toString());} 
		else if(origem==3) {linha6.setHorario("19:30"); System.out.println(linha6.toString());} 
		}
			
	int x7=0;	
			
	for(int i = 0; i<para7.length; i++) {
					
		if ((para7[i]==origem)||(para7[i]==destino)) {
			x7+=1;
		}}
						
		if (x7==2) {System.out.println("linha7 é uma opcao");
		linhass linha7 = new linhass("linha 7",11011, "o", 24);
		if (origem==3) {linha7.setHorario("07:00");System.out.println(linha7.toString());}
		else if(origem==2) {linha7.setHorario("07:45"); System.out.println(linha7.toString());}
		}
		
	int x8=0;	
		
		for(int i = 0; i<para8.length; i++) {
				
		if ((para8[i]==origem)||(para8[i]==destino)) {
			x8+=1;
		}}
					
		if (x8==2) {System.out.println("linha8 é uma opcao");
		linhass linha8 = new linhass("linha 8",10111, "o", 8);
		if (origem==9) {linha8.setHorario("06:00");System.out.println(linha8.toString());}
		else if(origem==8) {linha8.setHorario("06:40"); System.out.println(linha8.toString());}
		else if(origem==2) {linha8.setHorario("07:10"); System.out.println(linha8.toString());}
		else if(origem==1) {linha8.setHorario("07:30"); System.out.println(linha8.toString());} 
		else if(origem==4) {linha8.setHorario("07:40"); System.out.println(linha8.toString());} 
		else if(origem==5) {linha8.setHorario("07:50"); System.out.println(linha8.toString());} 
		else if(origem==6) {linha8.setHorario("08:00"); System.out.println(linha8.toString());} 
		else if(origem==3) {linha8.setHorario("08:10"); System.out.println(linha8.toString());} 
		else if(origem==7) {linha8.setHorario("08:30"); System.out.println(linha8.toString());} 
		}
	
			
		
	
	//set dos atrbutos das linhas fixas
		
		/*linhass linha1 = new linhass("linha 1",10001, "o",18);
		if (origem==1) {linha1.setHorario("09:30");System.out.println(linha1.toString());}
		else if(origem==2) {linha1.setHorario("09:50"); System.out.println(linha1.toString());}
		else if(origem==8) {linha1.setHorario("10:20"); System.out.println(linha1.toString());}
		else if(origem==9) {linha1.setHorario("10:50"); System.out.println(linha1.toString());} 

		
		
		linhass linha2 = new linhass("linha 2",10011, "o", 16);
		if (origem==4) {linha2.setHorario("14:10");System.out.println(linha2.toString());}
		else if(origem==5) {linha2.setHorario("14:20"); System.out.println(linha2.toString());}
		else if(origem==6) {linha2.setHorario("14:30"); System.out.println(linha2.toString());}
		else if(origem==3) {linha2.setHorario("14:40"); System.out.println(linha2.toString());} 
		else if(origem==7) {linha2.setHorario("15:00"); System.out.println(linha2.toString());} 
		
		
		
		linhass linha3 = new linhass("linha 3",10111, "o",18);
		if (origem==7) {linha3.setHorario("12:00");System.out.println(linha3.toString());}
		else if(origem==3) {linha3.setHorario("12:20"); System.out.println(linha3.toString());}
		else if(origem==2) {linha3.setHorario("13:10"); System.out.println(linha3.toString());}
		else if(origem==9) {linha3.setHorario("13:30"); System.out.println(linha3.toString());} 

		

		linhass linha4 = new linhass("linha 4",11111, "o",20);
		if (origem==1) {linha4.setHorario("16:30");System.out.println(linha4.toString());}
		else if(origem==6) {linha4.setHorario("16:55"); System.out.println(linha4.toString());}
		else if(origem==7) {linha4.setHorario("17:10"); System.out.println(linha4.toString());}
		
		
		
		linhass linha5 = new linhass("linha 5",11110, "o", 16);
		if (origem==1) {linha5.setHorario("08:00");System.out.println(linha5.toString());}
		else if(origem==4) {linha5.setHorario("08:10"); System.out.println(linha5.toString());}
		else if(origem==5) {linha5.setHorario("08:20"); System.out.println(linha5.toString());}
		else if(origem==6) {linha5.setHorario("08:30"); System.out.println(linha5.toString());} 
		else if(origem==3) {linha5.setHorario("08:40"); System.out.println(linha5.toString());} 
		
		
		
		linhass linha6 = new linhass("linha 6",11101, "o", 16);
		if (origem==2) {linha6.setHorario("18:30");System.out.println(linha6.toString());}
		else if(origem==4) {linha6.setHorario("19:00"); System.out.println(linha6.toString());}
		else if(origem==5) {linha6.setHorario("19:10"); System.out.println(linha6.toString());}
		else if(origem==6) {linha6.setHorario("19:20"); System.out.println(linha6.toString());} 
		else if(origem==3) {linha6.setHorario("19:30"); System.out.println(linha6.toString());} 
		
		
		
		linhass linha7 = new linhass("linha 7",11011, "o", 24);
		if (origem==3) {linha7.setHorario("07:00");System.out.println(linha7.toString());}
		else if(origem==2) {linha7.setHorario("07:45"); System.out.println(linha7.toString());}
		
		
		
		linhass linha8 = new linhass("linha 8",10111, "o", 8);
		if (origem==9) {linha8.setHorario("06:00");System.out.println(linha8.toString());}
		else if(origem==8) {linha8.setHorario("06:40"); System.out.println(linha8.toString());}
		else if(origem==2) {linha8.setHorario("07:10"); System.out.println(linha8.toString());}
		else if(origem==1) {linha8.setHorario("07:30"); System.out.println(linha8.toString());} 
		else if(origem==4) {linha8.setHorario("07:40"); System.out.println(linha8.toString());} 
		else if(origem==5) {linha8.setHorario("07:50"); System.out.println(linha8.toString());} 
		else if(origem==6) {linha8.setHorario("08:00"); System.out.println(linha8.toString());} 
		else if(origem==3) {linha8.setHorario("08:10"); System.out.println(linha8.toString());} 
		else if(origem==7) {linha8.setHorario("08:30"); System.out.println(linha8.toString());} */
		//....
	
	
	
	
	
	
	
}}

