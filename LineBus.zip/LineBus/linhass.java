package LineBus;

public class linhass {  //linhas pré determinadas
	public String nome;
	public int codigo;
	public String horario;
	public int preco;
	
	
	public linhass (String nome, int codigo, String horario, int preco) {
		this.nome = nome;
		this.codigo = codigo;
		this.horario = horario;
		this.preco = preco;
	
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getHorario() {
		return horario;
	}
	public void setHorario(String horario) {
		this.horario = horario;
	}
	public int getPreco() {
		return preco;
	}
	public void setPreco(int preco) {
		this.preco = preco;
	}




	public String toString() {
		return "linhass [codigo=" + codigo + ", horario=" + horario + ", preco=" + preco + "]";
	}




	
	
	
	
	

}
