package LineBus;

public class cadastro {

}
